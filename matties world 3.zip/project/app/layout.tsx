import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: "Mattie's World - Anonymous Messages & Missed Connections",
  description: 'Share your thoughts, feelings, and missed connections anonymously. Connect with others in a safe, engaging space.',
  openGraph: {
    title: "Mattie's World",
    description: 'Anonymous messaging platform for sharing thoughts and missed connections',
    images: ['https://images.unsplash.com/photo-1516726817505-f5ed825624d8?q=80&w=2069&auto=format&fit=crop'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}