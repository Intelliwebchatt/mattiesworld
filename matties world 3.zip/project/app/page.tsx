import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Heart, Search } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-background to-muted">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-pink-500 text-transparent bg-clip-text">
            Mattie&apos;s World
          </h1>
          <p className="text-lg text-muted-foreground">
            Share your thoughts, connect with others, stay anonymous
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="text-center">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-semibold mb-2">Anonymous Messages</h2>
              <p className="text-muted-foreground mb-4">
                Share your thoughts freely and safely
              </p>
              <Link href="/messages/new">
                <Button>Start Writing</Button>
              </Link>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="text-center">
              <Heart className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-semibold mb-2">Missed Connections</h2>
              <p className="text-muted-foreground mb-4">
                Find that special someone you crossed paths with
              </p>
              <Link href="/missed-connections">
                <Button>Explore</Button>
              </Link>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow">
            <div className="text-center">
              <Search className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-xl font-semibold mb-2">Search</h2>
              <p className="text-muted-foreground mb-4">
                Discover messages and connections
              </p>
              <Link href="/search">
                <Button>Search Now</Button>
              </Link>
            </div>
          </Card>
        </div>

        <section className="mt-16 text-center">
          <h2 className="text-2xl font-semibold mb-4">Latest Messages</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
            {/* Placeholder messages - will be replaced with real data */}
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="p-4">
                <p className="text-muted-foreground italic">
                  "This is where the latest messages will appear..."
                </p>
                <div className="mt-2 flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Anonymous</span>
                  <Button variant="ghost" size="sm">
                    Was this about me?
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}