import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import NewMessage from './pages/NewMessage'
import MissedConnections from './pages/MissedConnections'
import Search from './pages/Search'

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/messages/new" element={<NewMessage />} />
      <Route path="/missed-connections" element={<MissedConnections />} />
      <Route path="/search" element={<Search />} />
    </Routes>
  )
}

export default App