import { useEffect, useState } from 'react';
import { Card } from '../components/ui/card';
import { supabase } from '../lib/supabase';

interface Message {
  id: string;
  content: string;
  author_name: string;
  location: string;
  encounter_date: string;
  created_at: string;
}

export default function MissedConnections() {
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    async function fetchMissedConnections() {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('is_missed_connection', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching missed connections:', error);
        return;
      }

      setMessages(data || []);
    }

    fetchMissedConnections();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Missed Connections</h1>
        <div className="grid gap-6">
          {messages.map((message) => (
            <Card key={message.id} className="p-6">
              <p className="text-lg mb-4">{message.content}</p>
              <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                <span>Location: {message.location}</span>
                <span>Date: {new Date(message.encounter_date).toLocaleDateString()}</span>
                <span>Posted by: {message.author_name}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}