import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';

export default function NewMessage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    content: '',
    authorName: 'Anonymous',
    tags: '',
    isMissedConnection: false,
    location: '',
    encounterDate: '',
    mood: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { error } = await supabase.from('messages').insert([{
        content: formData.content,
        author_name: formData.authorName,
        tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
        is_missed_connection: formData.isMissedConnection,
        location: formData.location || null,
        encounter_date: formData.encounterDate || null,
        mood: formData.mood || null
      }]);

      if (error) throw error;
      
      navigate('/');
    } catch (error) {
      console.error('Error posting message:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-2xl mx-auto">
        <Card className="p-6">
          <h1 className="text-2xl font-bold mb-6">Share Your Message</h1>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Your Message</label>
              <Textarea
                value={formData.content}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="What's on your mind?"
                className="min-h-[150px]"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Display Name</label>
              <Input
                value={formData.authorName}
                onChange={(e) => setFormData(prev => ({ ...prev, authorName: e.target.value }))}
                placeholder="Anonymous"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Tags</label>
              <Input
                value={formData.tags}
                onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                placeholder="love, friendship, school (comma separated)"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isMissedConnection"
                checked={formData.isMissedConnection}
                onChange={(e) => setFormData(prev => ({ ...prev, isMissedConnection: e.target.checked }))}
                className="rounded border-gray-300"
              />
              <label htmlFor="isMissedConnection" className="text-sm font-medium">
                This is a missed connection
              </label>
            </div>
            
            {formData.isMissedConnection && (
              <>
                <div>
                  <label className="block text-sm font-medium mb-1">Location</label>
                  <Input
                    value={formData.location}
                    onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="Where did you meet?"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">When did it happen?</label>
                  <Input
                    type="date"
                    value={formData.encounterDate}
                    onChange={(e) => setFormData(prev => ({ ...prev, encounterDate: e.target.value }))}
                  />
                </div>
              </>
            )}
            
            <div>
              <label className="block text-sm font-medium mb-1">Mood</label>
              <select
                value={formData.mood}
                onChange={(e) => setFormData(prev => ({ ...prev, mood: e.target.value }))}
                className="w-full rounded-md border border-input bg-background px-3 py-2"
              >
                <option value="">Select a mood</option>
                <option value="hopeful">Hopeful</option>
                <option value="regretful">Regretful</option>
                <option value="curious">Curious</option>
                <option value="excited">Excited</option>
                <option value="nervous">Nervous</option>
              </select>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => navigate('/')}>
                Cancel
              </Button>
              <Button type="submit">Post Message</Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
}