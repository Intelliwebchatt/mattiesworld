import { useState } from 'react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';

interface Message {
  id: string;
  content: string;
  author_name: string;
  tags: string[];
  created_at: string;
  is_missed_connection: boolean;
  location?: string;
  encounter_date?: string;
  mood?: string;
}

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [category, setCategory] = useState('all');
  const [results, setResults] = useState<Message[]>([]);

  const handleSearch = async () => {
    try {
      let query = supabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: false });

      if (searchTerm) {
        query = query.or(`content.ilike.%${searchTerm}%,author_name.ilike.%${searchTerm}%,tags.cs.{${searchTerm}}`);
      }

      if (category === 'missed-connections') {
        query = query.eq('is_missed_connection', true);
      }

      if (dateRange.start) {
        query = query.gte('created_at', dateRange.start);
      }

      if (dateRange.end) {
        query = query.lte('created_at', dateRange.end);
      }

      const { data, error } = await query;

      if (error) throw error;
      setResults(data || []);
    } catch (error) {
      console.error('Error searching messages:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Search Messages</h1>
          <p className="text-muted-foreground">
            Find messages by keywords, dates, or categories
          </p>
        </header>

        <Card className="p-6 mb-8">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Search Terms</label>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by content, author, or tags..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Start Date</label>
                <Input
                  type="date"
                  value={dateRange.start}
                  onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">End Date</label>
                <Input
                  type="date"
                  value={dateRange.end}
                  onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-md border border-input bg-background px-3 py-2"
              >
                <option value="all">All Messages</option>
                <option value="missed-connections">Missed Connections Only</option>
              </select>
            </div>

            <Button onClick={handleSearch} className="w-full">
              Search
            </Button>
          </div>
        </Card>

        <div className="space-y-4">
          {results.map((message) => (
            <Card key={message.id} className="p-6">
              <div className="mb-4">
                <p className="text-lg mb-2">{message.content}</p>
                {message.tags && message.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {message.tags.map((tag, index) => (
                      <span
                        key={index}
                        className="bg-secondary text-secondary-foreground px-2 py-1 rounded-md text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
                {message.is_missed_connection && (
                  <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                    {message.location && <span>📍 {message.location}</span>}
                    {message.encounter_date && (
                      <span>📅 {format(new Date(message.encounter_date), 'PPP')}</span>
                    )}
                    {message.mood && <span className="capitalize">💭 {message.mood}</span>}
                  </div>
                )}
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  Posted by {message.author_name} on{' '}
                  {format(new Date(message.created_at), 'PPP')}
                </span>
                <Button variant="ghost" size="sm">
                  Was this about me?
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}