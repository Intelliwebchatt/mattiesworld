/*
  # Initial Schema Setup for Mattie's World

  1. New Tables
    - messages
      - id (uuid, primary key)
      - content (text)
      - author_name (text, optional)
      - tags (text[])
      - created_at (timestamp)
      - is_missed_connection (boolean)
      - location (text, optional)
      - encounter_date (date, optional)
      - mood (text)
    
    - replies
      - id (uuid, primary key)
      - message_id (uuid, foreign key)
      - content (text)
      - created_at (timestamp)
      - temp_id (text)

  2. Security
    - Enable RLS on all tables
    - Allow anonymous reads
    - Allow anonymous inserts with restrictions
*/

-- Messages table
CREATE TABLE messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    content text NOT NULL,
    author_name text DEFAULT 'Anonymous',
    tags text[] DEFAULT '{}',
    created_at timestamptz DEFAULT now(),
    is_missed_connection boolean DEFAULT false,
    location text,
    encounter_date date,
    mood text,
    CONSTRAINT content_length CHECK (char_length(content) >= 1 AND char_length(content) <= 2000),
    CONSTRAINT author_name_length CHECK (char_length(author_name) <= 50)
);

-- Replies table
CREATE TABLE replies (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id uuid REFERENCES messages(id) ON DELETE CASCADE,
    content text NOT NULL,
    created_at timestamptz DEFAULT now(),
    temp_id text NOT NULL,
    CONSTRAINT content_length CHECK (char_length(content) >= 1 AND char_length(content) <= 1000)
);

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE replies ENABLE ROW LEVEL SECURITY;

-- Policies for messages
CREATE POLICY "Allow anonymous read messages"
    ON messages
    FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow anonymous insert messages"
    ON messages
    FOR INSERT
    TO anon
    WITH CHECK (
        content IS NOT NULL AND
        char_length(content) <= 2000 AND
        char_length(coalesce(author_name, 'Anonymous')) <= 50
    );

-- Policies for replies
CREATE POLICY "Allow anonymous read replies"
    ON replies
    FOR SELECT
    TO anon
    USING (true);

CREATE POLICY "Allow anonymous insert replies"
    ON replies
    FOR INSERT
    TO anon
    WITH CHECK (
        content IS NOT NULL AND
        char_length(content) <= 1000
    );

-- Create indexes for better performance
CREATE INDEX messages_created_at_idx ON messages(created_at DESC);
CREATE INDEX messages_is_missed_connection_idx ON messages(is_missed_connection);
CREATE INDEX messages_tags_idx ON messages USING gin(tags);
CREATE INDEX replies_message_id_idx ON replies(message_id);